﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BookSharing.Models;
using Microsoft.AspNetCore.Authorization;
using log4net;
using BookSharing.ComponentHelper;

namespace BookSharing.Controllers
{
    //[Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class AuthorsController : ControllerBase
    {
        private readonly BookSharingContext _context;
        private readonly ILog Logger = Log4netHelper.GetLogger(typeof(AuthorsController));


        public AuthorsController(BookSharingContext context)
        {
            _context = context;
        }


        // GET: api/Authors
        [AllowAnonymous]
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Author>>> GetAuthors()
        {
            return await _context.Authors.ToListAsync();
        }

        // GET: api/Authors/5
        [HttpGet("author/{id}")]
        public async Task<ActionResult<Author>> GetAuthor(int id)
        {
            var author = (Author)null;
            try
            {
                author = await _context.Authors.FindAsync(id);
                _context.Entry(author)
                .Collection(au => au.BookAuthors)
                .Query()
                .Include(bauth => bauth.Book)
                .Load();

                Logger.Info($"Returned authors info for authorId:{id}");
            }
            catch (Exception ex)
            {
                Logger.Error(ex.Message+"for author id {id}");
                return NotFound();
            }
            

            //var query = ((System.Data.Objects.ObjectQuery)author).ToTraceString();
            //Logger.Info(author.);

            //if (author == null)
            //{
            //    return NotFound();
            //}

            return author;
        }

        // PUT: api/Authors/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("update/{id}")]
        public async Task<IActionResult> PutAuthor(int id, Author author)
        {
            if (id != author.Id)
            {
                return BadRequest();
            }

            _context.Entry(author).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AuthorExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Authors
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost("add")]
        public async Task<ActionResult<Author>> PostAuthor(Author author)
        {
            _context.Authors.Add(author);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetAuthor", new { id = author.Id }, author);
        }

        // DELETE: api/Authors/5
        [HttpDelete("delete/{id}")]
        public async Task<ActionResult<Author>> DeleteAuthor(int id)
        {
            var author = await _context.Authors.FindAsync(id);
            if (author == null)
            {
                return NotFound();
            }

            _context.Authors.Remove(author);
            await _context.SaveChangesAsync();

            return author;
        }

        private bool AuthorExists(int id)
        {
            return _context.Authors.Any(e => e.Id == id);
        }
    }
}
