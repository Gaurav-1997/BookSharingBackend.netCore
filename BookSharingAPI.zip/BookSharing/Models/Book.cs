﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace BookSharing.Models
{
    public partial class Book
    {
        public Book()
        {
            BookAuthors = new HashSet<BookAuthor>();
            BookCategories = new HashSet<BookCategory>();
            Sellers = new HashSet<Seller>();
        }

        public int Id { get; set; }
        public string BookTitle { get; set; }
        public string BookDescription { get; set; }
        public int? BookPrice { get; set; }
        public string Author { get; set; }
        public string BookCover { get; set; }
        public int? UserAsSellerId { get; set; }
        public string Category { get; set; }

        public virtual Seller UserAsSeller { get; set; }
        public virtual ICollection<BookAuthor> BookAuthors { get; set; }
        public virtual ICollection<BookCategory> BookCategories { get; set; }
        public virtual ICollection<Seller> Sellers { get; set; }
    }
}
